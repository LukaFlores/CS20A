#ifndef PENT_H
#define PENT_H

#include "life.h"
#include "constants.h"

class Pent : public Life {
    public:
        Pent(int r, int c) ; 
        ~Pent();
};




#endif //PENT_H

