#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>

//Insert your name is student id, letters and numbers only".
namespace StudentInfo {
	std::string name() { return "Luka Flores"; }
	std::string id() { return "1843513"; }
};

#endif
